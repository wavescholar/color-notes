function []=ax()

% AX hace los ejes cuadrados.
%
%USO: ax;


axis('square')