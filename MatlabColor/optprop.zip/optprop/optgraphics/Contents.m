%  
% OptProp\optgraphics
% Version 2.0   1 December 2006
% 
%   ballplot  - 3-D spheres plot.
%   bar3c     - Plot 3-D bar chart in true color
%   closesurf - Close a parameterized surface by concatenation.
%   helmholtz - Calculate and show  the Helmholtz "horseshoe"
%   optimage  - Display true color image converted to display.
%   viewgamut - Visualize a color gamut
%   viewlab   - Visualize an Lab color gamut
