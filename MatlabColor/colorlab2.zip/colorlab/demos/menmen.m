function K=menmen;

% MENMEN men� de demos de COLORLAB

%K=menu('Demos de COLORLAB:','Calibrado del monitor','Generaci�n de colores','Descomposici�n en canales','Variaci�n de pureza y luminancia','Variaci�n del iluminante','Filtrado de los canales crom�ticos','Cuantizaci�n del espacio triest�mulo','Generaci�n de redes','Sistema de referencia','Cerrar');
K=menu('COLORLAB Demos:','CRT Calibration','Color Generation','Descomposition into channels','Editing purity and luminance','Changing the illuminant','Filtering the chromatic channels','Color space quantization','Color system','Close');