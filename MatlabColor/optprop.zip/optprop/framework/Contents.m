%  
% OptProp\framework
% Version 2.0   1 December 2006
% 
%   dcwf       - Return the default color matching function.
%   dwl        - Return or set the session default wavelength range.
%   optgetpref - Get OptProp preferences.
%   optproc    - Block and argument processing for OptProp conversions.
%   optsetpref - Set OptProp preferences.
