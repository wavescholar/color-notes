%  
% OptProp\generate
% Version 2.0   1 December 2006
% 
%   addmix       - Generate color test map for additive mixings.
%   colorchecker - Spectral data of a Macbeth ColorChecker.
%   colormix     - Mix primary RGB or CMY... colors/inks.
%   concmix      - Generate saturation/value map of hues.
%   rosch        - Create the Rosch color solid.
%   submix       - Generate color test map for subtractive mixings.
