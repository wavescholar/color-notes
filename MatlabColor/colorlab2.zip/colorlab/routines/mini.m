function [m]=mini(a);

%USO  m=maxi(a)  calcula el maximo de una matriz

m=min(min(a));
